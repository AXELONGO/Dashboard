'use client';

import { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

interface VehicleUnit {
  unidad: string;
  kmTotal: number;
  duracionTotal: string;
  velocidadMin?: number;
  velocidadMax?: number;
  estado?: 'activo' | 'detenido';
  additionalData?: Record<string, any>;
}

interface DayData {
  fecha: string;
  unidades: VehicleUnit[];
}

interface ApiResponse {
  data: DayData[];
  error?: string;
  usingMockData?: boolean;
  success?: boolean;
  debug?: any;
}

export default function TestSheetsPage() {
  const [data, setData] = useState<ApiResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/sheets');
      const result: ApiResponse = await response.json();
      setData(result);
    } catch (error) {
      console.error('Error fetching data:', error);
      setData({
        data: [],
        error: 'Error de conexión',
        success: false
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Test Google Sheets API</h1>
          <button
            onClick={fetchData}
            disabled={isLoading}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            {isLoading ? 'Cargando...' : 'Actualizar'}
          </button>
        </div>

        {data?.error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <h3 className="text-red-800 font-semibold mb-2">Error</h3>
            <p className="text-red-700">{data.error}</p>
          </div>
        )}

        {data?.debug && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h3 className="text-blue-800 font-semibold mb-2">Debug Information</h3>
            <pre className="text-sm text-blue-700 overflow-auto">
              {JSON.stringify(data.debug, null, 2)}
            </pre>
          </div>
        )}

        {data?.data && data.data.length > 0 && (
          <div className="space-y-6">
            {data.data.map((dayData, dayIndex) => (
              <div key={dayIndex} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">
                  Fecha: {dayData.fecha} ({dayData.unidades.length} unidades)
                </h2>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Unidad
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          KM Total
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Duración
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Vel. Min
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Vel. Max
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Estado
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Datos Adicionales
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {dayData.unidades.map((unit, unitIndex) => (
                        <tr key={unitIndex} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {unit.unidad}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {unit.kmTotal.toFixed(2)} km
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {unit.duracionTotal}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {unit.velocidadMin ? `${unit.velocidadMin} km/h` : 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {unit.velocidadMax ? `${unit.velocidadMax} km/h` : 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              unit.estado === 'activo' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {unit.estado}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500">
                            {unit.additionalData && Object.keys(unit.additionalData).length > 0 ? (
                              <details className="cursor-pointer">
                                <summary className="text-blue-600 hover:text-blue-800">
                                  Ver datos ({Object.keys(unit.additionalData).length})
                                </summary>
                                <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                                  {Object.entries(unit.additionalData).map(([key, value]) => (
                                    <div key={key} className="flex justify-between py-1">
                                      <span className="font-medium">{key}:</span>
                                      <span>{value}</span>
                                    </div>
                                  ))}
                                </div>
                              </details>
                            ) : (
                              'Sin datos adicionales'
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        )}

        {data?.data && data.data.length === 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-yellow-700">No se encontraron datos en la hoja de cálculo.</p>
          </div>
        )}
      </div>
    </div>
  );
}
