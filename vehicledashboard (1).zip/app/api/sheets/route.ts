import { NextResponse } from 'next/server';

const SHEET_ID = '1vjKADJdBxPQBi4eq7FF-BnsAmbIqvovR_JHKTf161CY';
const GID = '555169901';

interface VehicleData {
  fecha: string;
  unidad: string;
  kmTotal: number;
  duracionTotal: string;
  velocidadMin?: number;
  velocidadMax?: number;
  estado?: 'activo' | 'detenido';
  [key: string]: any;
}

interface GroupedData {
  [fecha: string]: VehicleData[];
}

function parseCSV(csvText: string): string[][] {
  const lines = csvText.split('\n').filter(line => line.trim());
  const result: string[][] = [];

  for (const line of lines) {
    const row: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        row.push(current.trim().replace(/^"|"$/g, ''));
        current = '';
      } else {
        current += char;
      }
    }
    
    row.push(current.trim().replace(/^"|"$/g, ''));
    result.push(row);
  }

  return result;
}

function extractDateFromHeader(header: string): string | null {
  const patterns = [
    /(\d{4}-\d{2}-\d{2})/,
    /(\d{2}\/\d{2}\/\d{4})/,
    /(\d{2}-\d{2}-\d{4})/,
  ];

  for (const pattern of patterns) {
    const match = header.match(pattern);
    if (match) {
      let dateStr = match[1];
      if (dateStr.includes('/')) {
        const parts = dateStr.split('/');
        if (parts.length === 3) {
          dateStr = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
      } else if (dateStr.match(/^\d{2}-\d{2}-\d{4}$/)) {
        const parts = dateStr.split('-');
        dateStr = `${parts[2]}-${parts[1]}-${parts[0]}`;
      }
      return dateStr;
    }
  }

  return null;
}

function removeDuplicateUnits(unidades: VehicleData[]): VehicleData[] {
  const unitMap = new Map<string, VehicleData>();
  
  for (const unit of unidades) {
    const existingUnit = unitMap.get(unit.unidad);
    
    if (!existingUnit) {
      unitMap.set(unit.unidad, unit);
    } else {
      const currentScore = calculateUnitScore(unit);
      const existingScore = calculateUnitScore(existingUnit);
      
      if (currentScore > existingScore) {
        unitMap.set(unit.unidad, unit);
        console.log(`Replaced duplicate unit ${unit.unidad}: new score ${currentScore} > old score ${existingScore}`);
      }
    }
  }
  
  return Array.from(unitMap.values());
}

function calculateUnitScore(unit: VehicleData): number {
  let score = unit.kmTotal || 0;
  
  if (unit.velocidadMax) {
    score += unit.velocidadMax * 0.1;
  }
  
  const durationMinutes = parseDurationToMinutes(unit.duracionTotal);
  score += durationMinutes * 0.01;
  
  return score;
}

function parseDurationToMinutes(duration: string): number {
  if (!duration) return 0;
  
  const hourMatch = duration.match(/(\d+)h/);
  const minuteMatch = duration.match(/(\d+)m/);
  const secondMatch = duration.match(/(\d+)s/);
  
  const hours = hourMatch ? parseInt(hourMatch[1]) : 0;
  const minutes = minuteMatch ? parseInt(minuteMatch[1]) : 0;
  const seconds = secondMatch ? parseInt(secondMatch[1]) : 0;
  
  return hours * 60 + minutes + seconds / 60;
}

function determineVehicleStatus(unit: VehicleData): 'activo' | 'detenido' {
  // Consider a vehicle active if it has traveled more than 1km or has a max speed > 10 km/h
  if (unit.kmTotal > 1 || (unit.velocidadMax && unit.velocidadMax > 10)) {
    return 'activo';
  }
  return 'detenido';
}

function parseSheetsData(data: string[][]): GroupedData {
  if (data.length < 2) return {};

  const headers = data[0];
  const groupedData: GroupedData = {};

  console.log('Headers (A-T):', headers.slice(0, 20));
  console.log('Total columns found:', headers.length);

  const columnLabels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T'];

  const dateSections: { [date: string]: { startCol: number; endCol: number; columns: string[] } } = {};

  for (let i = 0; i < Math.min(headers.length, 20); i++) {
    const header = headers[i];
    const extractedDate = extractDateFromHeader(header);
    
    if (extractedDate) {
      if (!dateSections[extractedDate]) {
        dateSections[extractedDate] = { 
          startCol: i, 
          endCol: Math.min(i + 5, 19),
          columns: []
        };
      }
      
      const sectionColumns = [];
      for (let j = i; j < Math.min(i + 6, headers.length, 20); j++) {
        sectionColumns.push(headers[j]);
      }
      dateSections[extractedDate].columns = sectionColumns;
      dateSections[extractedDate].endCol = Math.min(i + 5, 19);
    }
  }

  console.log('Date sections found:', dateSections);

  if (Object.keys(dateSections).length === 0) {
    console.log('No horizontal date sections found, trying vertical parsing...');
    
    const fechaIdx = headers.slice(0, 20).findIndex(h => h.toLowerCase().includes('fecha'));
    const unidadIdx = headers.slice(0, 20).findIndex(h => h.toLowerCase().includes('unidad'));
    const kmIdx = headers.slice(0, 20).findIndex(h => h.toLowerCase().includes('km'));
    const duracionIdx = headers.slice(0, 20).findIndex(h => h.toLowerCase().includes('duracion'));
    const velMinIdx = headers.slice(0, 20).findIndex(h => h.toLowerCase().includes('velocidad') && h.toLowerCase().includes('min'));
    const velMaxIdx = headers.slice(0, 20).findIndex(h => h.toLowerCase().includes('velocidad') && h.toLowerCase().includes('max'));
    
    console.log('Column indices found:', { fechaIdx, unidadIdx, kmIdx, duracionIdx, velMinIdx, velMaxIdx });
    
    if (fechaIdx >= 0 || unidadIdx >= 0) {
      for (let i = 1; i < data.length; i++) {
        const row = data[i];
        const rowData = row.slice(0, 20);
        
        let fecha = '';
        if (fechaIdx >= 0 && rowData[fechaIdx]) {
          fecha = rowData[fechaIdx];
        } else {
          for (let j = 0; j < Math.min(5, rowData.length); j++) {
            const cellDate = extractDateFromHeader(rowData[j] || '');
            if (cellDate) {
              fecha = cellDate;
              break;
            }
          }
        }
        
        if (fecha) {
          const vehicleData: VehicleData = {
            fecha,
            unidad: unidadIdx >= 0 ? rowData[unidadIdx] || 'N/A' : 'N/A',
            kmTotal: kmIdx >= 0 ? parseFloat(rowData[kmIdx]?.replace(/[^\d.-]/g, '') || '0') || 0 : 0,
            duracionTotal: duracionIdx >= 0 ? rowData[duracionIdx] || '0h 0m' : '0h 0m',
            velocidadMin: velMinIdx >= 0 ? parseFloat(rowData[velMinIdx]?.replace(/[^\d.-]/g, '') || '0') || undefined : undefined,
            velocidadMax: velMaxIdx >= 0 ? parseFloat(rowData[velMaxIdx]?.replace(/[^\d.-]/g, '') || '0') || undefined : undefined,
          };
          
          vehicleData.estado = determineVehicleStatus(vehicleData);
          
          for (let j = 0; j < Math.min(rowData.length, 20); j++) {
            const columnLabel = columnLabels[j];
            const cellValue = rowData[j];
            if (cellValue && cellValue.trim()) {
              vehicleData[`column_${columnLabel}`] = cellValue.trim();
            }
          }
          
          if (!groupedData[fecha]) {
            groupedData[fecha] = [];
          }
          
          if (vehicleData.unidad !== 'N/A' || vehicleData.kmTotal > 0 || Object.keys(vehicleData).length > 4) {
            groupedData[fecha].push(vehicleData);
          }
        }
      }
    }
  } else {
    for (const [date, section] of Object.entries(dateSections)) {
      groupedData[date] = [];
      
      const sectionHeaders = section.columns;
      const unidadIdx = sectionHeaders.findIndex(h => h.toLowerCase().includes('unidad'));
      const kmIdx = sectionHeaders.findIndex(h => h.toLowerCase().includes('km'));
      const duracionIdx = sectionHeaders.findIndex(h => h.toLowerCase().includes('duracion'));
      const velMinIdx = sectionHeaders.findIndex(h => h.toLowerCase().includes('velocidad') && h.toLowerCase().includes('min'));
      const velMaxIdx = sectionHeaders.findIndex(h => h.toLowerCase().includes('velocidad') && h.toLowerCase().includes('max'));
      
      for (let i = 1; i < data.length; i++) {
        const row = data[i];
        const startCol = section.startCol;
        const endCol = Math.min(section.endCol, 19);
        
        if (row.length > startCol) {
          const sectionRow = row.slice(startCol, endCol + 1);
          
          if (sectionRow.some(cell => cell && cell.trim())) {
            const unidad = unidadIdx >= 0 && sectionRow[unidadIdx] ? sectionRow[unidadIdx].trim() : '';
            const kmStr = kmIdx >= 0 && sectionRow[kmIdx] ? sectionRow[kmIdx].trim() : '0';
            const duracion = duracionIdx >= 0 && sectionRow[duracionIdx] ? sectionRow[duracionIdx].trim() : '0h 0m';
            
            if (unidad || sectionRow.some(cell => cell && cell.trim())) {
              const vehicleData: VehicleData = {
                fecha: date,
                unidad: unidad || 'N/A',
                kmTotal: parseFloat(kmStr.replace(/[^\d.-]/g, '')) || 0,
                duracionTotal: duracion,
                velocidadMin: velMinIdx >= 0 ? parseFloat(sectionRow[velMinIdx]?.replace(/[^\d.-]/g, '') || '0') || undefined : undefined,
                velocidadMax: velMaxIdx >= 0 ? parseFloat(sectionRow[velMaxIdx]?.replace(/[^\d.-]/g, '') || '0') || undefined : undefined,
              };
              
              vehicleData.estado = determineVehicleStatus(vehicleData);
              
              for (let j = 0; j < sectionRow.length; j++) {
                const globalColIndex = startCol + j;
                if (globalColIndex < 20) {
                  const columnLabel = columnLabels[globalColIndex];
                  const cellValue = sectionRow[j];
                  if (cellValue && cellValue.trim()) {
                    vehicleData[`column_${columnLabel}`] = cellValue.trim();
                  }
                }
              }
              
              groupedData[date].push(vehicleData);
            }
          }
        }
      }
    }
  }

  for (const fecha in groupedData) {
    const originalCount = groupedData[fecha].length;
    groupedData[fecha] = removeDuplicateUnits(groupedData[fecha]);
    const finalCount = groupedData[fecha].length;
    
    if (originalCount !== finalCount) {
      console.log(`Date ${fecha}: Removed ${originalCount - finalCount} duplicate units (${originalCount} -> ${finalCount})`);
    }
  }

  return groupedData;
}

export async function GET() {
  try {
    console.log(`Fetching data from Google Sheets with GID: ${GID} (columns A-T)`);
    
    const urls = [
      `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=${GID}`,
      `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&gid=${GID}`,
    ];
    
    let csvText = '';
    let lastError = null;
    
    for (const url of urls) {
      try {
        console.log(`Trying URL: ${url}`);
        
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; VehicleDashboard/1.0)',
          },
          redirect: 'follow',
        });
        
        console.log(`Response status: ${response.status}`);
        
        if (response.ok) {
          csvText = await response.text();
          console.log(`Successfully fetched data (${csvText.length} characters)`);
          break;
        } else {
          lastError = new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
      } catch (error) {
        console.log(`Failed with URL ${url}:`, error);
        lastError = error;
        continue;
      }
    }
    
    if (!csvText) {
      throw lastError || new Error('Failed to fetch data from all attempted URLs');
    }
    
    const data = parseCSV(csvText);
    console.log(`Parsed ${data.length} rows with up to ${data[0]?.length || 0} columns`);
    
    const groupedData = parseSheetsData(data);
    console.log('Grouped data:', Object.keys(groupedData));
    
    const result = Object.entries(groupedData).map(([fecha, unidades]) => ({
      fecha,
      unidades: unidades.map(u => ({
        unidad: u.unidad,
        kmTotal: u.kmTotal,
        duracionTotal: u.duracionTotal,
        velocidadMin: u.velocidadMin,
        velocidadMax: u.velocidadMax,
        estado: u.estado,
        additionalData: Object.keys(u)
          .filter(key => key.startsWith('column_'))
          .reduce((acc, key) => {
            acc[key] = u[key];
            return acc;
          }, {} as Record<string, any>)
      }))
    }));
    
    result.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
    
    return NextResponse.json({
      data: result,
      success: true,
      usingMockData: false,
      debug: {
        totalRows: data.length,
        totalColumns: data[0]?.length || 0,
        columnsAToT: Math.min(data[0]?.length || 0, 20),
        groupedDates: Object.keys(groupedData).length,
        totalRecords: Object.values(groupedData).flat().length,
        gid: GID,
        sampleHeaders: data[0]?.slice(0, 20) || [],
        duplicatesRemoved: true,
      }
    });
    
  } catch (error) {
    console.error('Error fetching Google Sheets data:', error);
    
    return NextResponse.json({
      data: [],
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      usingMockData: false,
      debug: {
        errorDetails: error instanceof Error ? error.stack : 'Unknown error',
        gid: GID,
        note: 'No mock data provided - only real Google Sheets data',
        duplicatesRemoved: true,
      }
    });
  }
}
