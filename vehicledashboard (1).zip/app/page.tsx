'use client';

import { useState, useEffect, useRef } from 'react';
import { RefreshCw, Calendar, Car, Route, Clock, TrendingUp, TrendingDown, Play, Pause, AlertTriangle, Info, ArrowLeft, MapPin, Gauge } from 'lucide-react';

interface VehicleUnit {
  unidad: string;
  kmTotal: number;
  duracionTotal: string;
  velocidadMin?: number;
  velocidadMax?: number;
  estado?: 'activo' | 'detenido';
  additionalData?: Record<string, any>;
}

interface DayData {
  fecha: string;
  unidades: VehicleUnit[];
}

interface ApiResponse {
  data: DayData[];
  error?: string;
  usingMockData?: boolean;
  success?: boolean;
  debug?: any;
}

interface UnitHistoricalData {
  fecha: string;
  kmTotal: number;
  duracionMinutes: number;
  duracionTotal: string;
  hasData: boolean;
}

function parseDurationToMinutes(duration: string): number {
  if (!duration) return 0;
  
  const hourMatch = duration.match(/(\d+)h/);
  const minuteMatch = duration.match(/(\d+)m/);
  const secondMatch = duration.match(/(\d+)s/);
  
  const hours = hourMatch ? parseInt(hourMatch[1]) : 0;
  const minutes = minuteMatch ? parseInt(minuteMatch[1]) : 0;
  const seconds = secondMatch ? parseInt(secondMatch[1]) : 0;
  
  return hours * 60 + minutes + seconds / 60;
}

function formatDateToString(date: Date): string {
  return date.toISOString().split('T')[0];
}

function UnitDetailView({ 
  unit, 
  onBack,
  availableDates,
  selectedDate,
  onDateChange,
  allVehicleData
}: { 
  unit: VehicleUnit;
  onBack: () => void;
  availableDates: string[];
  selectedDate: string;
  onDateChange: (date: string) => void;
  allVehicleData: DayData[];
}) {
  // Get 7 days of data: selected date + 6 days back
  const getUnitHistoricalData = (): UnitHistoricalData[] => {
    const historicalData: UnitHistoricalData[] = [];
    const selectedDateObj = new Date(selectedDate);
    
    // Generate 7 days: selected date + 6 days back
    for (let i = 6; i >= 0; i--) {
      const targetDate = new Date(selectedDateObj);
      targetDate.setDate(selectedDateObj.getDate() - i);
      const dateString = formatDateToString(targetDate);
      
      // Find data for this specific date and unit
      const dayData = allVehicleData.find(d => d.fecha === dateString);
      const unitData = dayData?.unidades.find(u => u.unidad === unit.unidad);
      
      if (unitData) {
        historicalData.push({
          fecha: dateString,
          kmTotal: unitData.kmTotal,
          duracionMinutes: parseDurationToMinutes(unitData.duracionTotal),
          duracionTotal: unitData.duracionTotal,
          hasData: true
        });
      } else {
        // Add empty data for days without information
        historicalData.push({
          fecha: dateString,
          kmTotal: 0,
          duracionMinutes: 0,
          duracionTotal: '0h 0m',
          hasData: false
        });
      }
    }
    
    return historicalData;
  };

  const historicalData = getUnitHistoricalData();
  const maxKm = Math.max(...historicalData.map(d => d.kmTotal), 1);
  const maxMinutes = Math.max(...historicalData.map(d => d.duracionMinutes), 1);

  // Function to check if speed is excessive (over 80 km/h as example threshold)
  const isSpeedExcessive = (speed?: number) => {
    return speed && speed > 80;
  };

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-blue-600 hover:text-blue-800 mb-6 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Volver al dashboard
      </button>

      {/* Unit Details Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Unit Name */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-600 mb-2">Nombre de unidad</h3>
          <div className="flex items-center gap-2">
            <Car className="h-5 w-5 text-blue-600" />
            <span className="text-lg font-bold text-gray-900">{unit.unidad}</span>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Estado: <span className={`font-medium ${unit.estado === 'activo' ? 'text-green-600' : 'text-red-600'}`}>
              {unit.estado === 'activo' ? 'Activo' : 'Detenido'}
            </span>
          </p>
        </div>

        {/* Unit Location/Odometer */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-600 mb-2">Ubicación de unidad / Odómetro</h3>
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="h-4 w-4 text-green-600" />
            <span className="text-sm text-gray-700">
              {unit.additionalData?.ruta || 'Ubicación no disponible'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Gauge className="h-4 w-4 text-orange-600" />
            <span className="text-lg font-semibold text-gray-900">
              {unit.kmTotal.toFixed(2)} km
            </span>
          </div>
        </div>

        {/* Date Dropdown */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-600 mb-2">Menú desplegable de fechas</h3>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-blue-600" />
            <select
              value={selectedDate}
              onChange={(e) => onDateChange(e.target.value)}
              className="flex-1 bg-transparent border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {availableDates.map((date) => (
                <option key={date} value={date}>
                  {date}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Current Day Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Route className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-600">Distancia Total</span>
          </div>
          <span className="text-2xl font-bold text-gray-900">{unit.kmTotal.toFixed(2)} km</span>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium text-gray-600">Tiempo Total</span>
          </div>
          <span className="text-2xl font-bold text-gray-900">{unit.duracionTotal}</span>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-red-600" />
            <span className="text-sm font-medium text-gray-600">Velocidad Máx</span>
          </div>
          <span className="text-2xl font-bold text-gray-900">
            {unit.velocidadMax ? `${unit.velocidadMax} km/h` : 'N/A'}
          </span>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium text-gray-600">Velocidad Mín</span>
          </div>
          <span className="text-2xl font-bold text-gray-900">
            {unit.velocidadMin ? `${unit.velocidadMin} km/h` : 'N/A'}
          </span>
        </div>
      </div>

      {/* Historical Charts - 7 Days Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Kilometers Chart */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-2">
            Kilómetros por Día
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            Comparativa de 7 días (día actual + 6 días anteriores)
          </p>
          
          <div className="relative h-64">
            {/* Chart Container */}
            <div className="relative h-full border border-gray-200 rounded-lg p-4">
              {/* Y-axis labels */}
              <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-500 pr-2">
                <span>{maxKm.toFixed(0)}</span>
                <span>{(maxKm * 0.75).toFixed(0)}</span>
                <span>{(maxKm * 0.5).toFixed(0)}</span>
                <span>{(maxKm * 0.25).toFixed(0)}</span>
                <span>0</span>
              </div>
              
              {/* Chart area */}
              <div className="ml-8 h-full relative flex items-end justify-around gap-1 pb-8">
                {/* Grid lines */}
                <div className="absolute inset-0">
                  {[0, 25, 50, 75, 100].map((percent) => (
                    <div
                      key={percent}
                      className="absolute w-full border-t border-gray-100"
                      style={{ top: `${percent}%` }}
                    />
                  ))}
                </div>
                
                {/* Bars */}
                {historicalData.map((data, index) => {
                  const barHeight = maxKm > 0 ? (data.kmTotal / maxKm) * 100 : 0;
                  const isCurrentDate = data.fecha === selectedDate;
                  const hasData = data.hasData;
                  
                  return (
                    <div key={index} className="flex flex-col items-center flex-1 max-w-10">
                      <div
                        className={`w-full rounded-t transition-all duration-300 ${
                          !hasData 
                            ? 'bg-gray-200 border-2 border-dashed border-gray-300' 
                            : isCurrentDate 
                              ? 'bg-blue-600' 
                              : 'bg-blue-300'
                        }`}
                        style={{ height: `${Math.max(barHeight, hasData ? 2 : 8)}%` }}
                        title={`${data.fecha}: ${hasData ? `${data.kmTotal.toFixed(2)} km` : 'Sin datos'}`}
                      />
                    </div>
                  );
                })}
              </div>
              
              {/* X-axis labels */}
              <div className="absolute bottom-0 left-8 right-0 flex justify-around text-xs text-gray-500">
                {historicalData.map((data, index) => (
                  <span key={index} className="transform -rotate-45 origin-top-left text-center">
                    {new Date(data.fecha).toLocaleDateString('es-ES', { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Time Chart */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-2">
            Tiempo por Día
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            Comparativa de 7 días (día actual + 6 días anteriores)
          </p>
          
          <div className="relative h-64">
            {/* Chart Container */}
            <div className="relative h-full border border-gray-200 rounded-lg p-4">
              {/* Y-axis labels */}
              <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-500 pr-2">
                <span>{Math.floor(maxMinutes / 60)}h {Math.floor(maxMinutes % 60)}m</span>
                <span>{Math.floor((maxMinutes * 0.75) / 60)}h {Math.floor((maxMinutes * 0.75) % 60)}m</span>
                <span>{Math.floor((maxMinutes * 0.5) / 60)}h {Math.floor((maxMinutes * 0.5) % 60)}m</span>
                <span>{Math.floor((maxMinutes * 0.25) / 60)}h {Math.floor((maxMinutes * 0.25) % 60)}m</span>
                <span>0</span>
              </div>
              
              {/* Chart area */}
              <div className="ml-8 h-full relative flex items-end justify-around gap-1 pb-8">
                {/* Grid lines */}
                <div className="absolute inset-0">
                  {[0, 25, 50, 75, 100].map((percent) => (
                    <div
                      key={percent}
                      className="absolute w-full border-t border-gray-100"
                      style={{ top: `${percent}%` }}
                    />
                  ))}
                </div>
                
                {/* Bars */}
                {historicalData.map((data, index) => {
                  const barHeight = maxMinutes > 0 ? (data.duracionMinutes / maxMinutes) * 100 : 0;
                  const isCurrentDate = data.fecha === selectedDate;
                  const hasData = data.hasData;
                  
                  return (
                    <div key={index} className="flex flex-col items-center flex-1 max-w-10">
                      <div
                        className={`w-full rounded-t transition-all duration-300 ${
                          !hasData 
                            ? 'bg-gray-200 border-2 border-dashed border-gray-300' 
                            : isCurrentDate 
                              ? 'bg-green-600' 
                              : 'bg-green-300'
                        }`}
                        style={{ height: `${Math.max(barHeight, hasData ? 2 : 8)}%` }}
                        title={`${data.fecha}: ${hasData ? data.duracionTotal : 'Sin datos'}`}
                      />
                    </div>
                  );
                })}
              </div>
              
              {/* X-axis labels */}
              <div className="absolute bottom-0 left-8 right-0 flex justify-around text-xs text-gray-500">
                {historicalData.map((data, index) => (
                  <span key={index} className="transform -rotate-45 origin-top-left text-center">
                    {new Date(data.fecha).toLocaleDateString('es-ES', { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function VehicleDashboard() {
  const [vehicleData, setVehicleData] = useState<DayData[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedUnit, setSelectedUnit] = useState<VehicleUnit | null>(null);
  const [showUnitDetail, setShowUnitDetail] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usingMockData, setUsingMockData] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [nextUpdate, setNextUpdate] = useState<Date | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchData = async () => {
    try {
      const response = await fetch('/api/sheets');
      const result: ApiResponse = await response.json();
      
      setVehicleData(result.data || []);
      setUsingMockData(result.usingMockData || false);
      setError(result.success === false ? result.error || null : null);
      setLastUpdated(new Date());
      
      const nextUpdateTime = new Date();
      nextUpdateTime.setMinutes(nextUpdateTime.getMinutes() + 30);
      setNextUpdate(nextUpdateTime);
      
      if (result.data && result.data.length > 0 && !selectedDate) {
        setSelectedDate(result.data[0].fecha);
      }
    } catch (err) {
      setError('Error de conexión');
      console.error('Error fetching data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    
    intervalRef.current = setInterval(() => {
      console.log('Auto-refreshing data...');
      fetchData();
    }, 30 * 60 * 1000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const selectedData = vehicleData.find(data => data.fecha === selectedDate);
  const maxKm = Math.max(...(selectedData?.unidades.map(unit => unit.kmTotal) || [0]));

  // Function to check if speed is excessive (over 80 km/h as example threshold)
  const isSpeedExcessive = (speed?: number) => {
    return speed && speed > 80;
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  };

  const handleRefresh = () => {
    setIsLoading(true);
    fetchData();
  };

  const handleUnitClick = (unit: VehicleUnit) => {
    setSelectedUnit(unit);
    setShowUnitDetail(true);
  };

  const handleBackToDashboard = () => {
    setShowUnitDetail(false);
    setSelectedUnit(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-gray-600" />
          <p className="text-gray-600">Cargando...</p>
        </div>
      </div>
    );
  }

  // Show unit detail view if a unit is selected
  if (showUnitDetail && selectedUnit) {
    return (
      <UnitDetailView
        unit={selectedUnit}
        onBack={handleBackToDashboard}
        availableDates={vehicleData.map(d => d.fecha)}
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        allVehicleData={vehicleData}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="grid grid-cols-[300px_1fr] min-h-screen">
        {/* Units Panel - Left Side */}
        <div className="bg-white border-r border-gray-200 overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-1">Unidades</h3>
            <p className="text-sm text-gray-600">
              {selectedData?.unidades.length || 0} vehículos
            </p>
            <p className="text-xs text-blue-600 mt-1">
              Haz clic en una unidad para ver detalles
            </p>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {selectedData?.unidades.map((unit, index) => (
              <div
                key={index}
                className={`p-3 border-b border-gray-100 cursor-pointer transition-all duration-200 hover:bg-blue-50 ${
                  selectedUnit?.unidad === unit.unidad ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''
                }`}
                onClick={() => handleUnitClick(unit)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {unit.estado === 'activo' ? (
                      <Play className="h-4 w-4 text-green-500" />
                    ) : (
                      <Pause className="h-4 w-4 text-red-500" />
                    )}
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{unit.unidad}</p>
                      <p className="text-xs text-gray-500">{unit.kmTotal.toFixed(2)} km</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-600">{unit.duracionTotal}</p>
                    {unit.velocidadMax && (
                      <p className={`text-xs ${isSpeedExcessive(unit.velocidadMax) ? 'text-red-600 font-bold' : 'text-blue-600'}`}>
                        {unit.velocidadMax} km/h
                        {isSpeedExcessive(unit.velocidadMax) && (
                          <AlertTriangle className="inline h-3 w-3 ml-1" />
                        )}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content - Right Side */}
        <div className="p-6 overflow-y-auto">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard de Unidades</h1>
              <p className="text-blue-600 text-sm mb-1">
                Monitoreo de kilómetros recorridos por <span className="underline">unidad</span>
              </p>
              <div className="text-xs text-gray-500 space-y-1">
                {lastUpdated && (
                  <p>Última actualización: {formatTime(lastUpdated)}</p>
                )}
                {nextUpdate && (
                  <p>Próxima actualización: {formatTime(nextUpdate)}</p>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg">
                <Calendar className="h-4 w-4 text-gray-500" />
                <select
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="bg-transparent border-none outline-none text-gray-900 font-medium"
                >
                  {vehicleData.map((data) => (
                    <option key={data.fecha} value={data.fecha}>
                      {data.fecha}
                    </option>
                  ))}
                </select>
              </div>
              
              <button
                onClick={handleRefresh}
                disabled={isLoading}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                Actualizar
              </button>
            </div>
          </div>

          {/* Error Alert */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          {/* Vehicle Details Chart */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-1">Detalle por Unidad</h2>
              <p className="text-gray-600 text-sm">
                Kilómetros recorridos y duración por vehículo el {selectedDate || 'Selecciona una fecha'}
              </p>
            </div>

            {!selectedData || selectedData.unidades.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Car className="h-16 w-16 mx-auto mb-4 opacity-30" />
                <p>No hay datos disponibles para esta fecha</p>
              </div>
            ) : (
              <div className="space-y-6">
                {selectedData.unidades.map((unit, index) => {
                  const barWidth = maxKm > 0 ? (unit.kmTotal / maxKm) * 100 : 0;
                  const isSelected = selectedUnit?.unidad === unit.unidad;
                  const hasSpeedViolation = isSpeedExcessive(unit.velocidadMax);
                  
                  return (
                    <div
                      key={index}
                      className={`grid grid-cols-[120px_1fr_120px_120px] gap-4 items-center py-4 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                        isSelected 
                          ? 'bg-blue-50 border-2 border-blue-200' 
                          : 'hover:bg-gray-50 border-2 border-transparent'
                      }`}
                      onClick={() => handleUnitClick(unit)}
                    >
                      {/* Vehicle Name and Icon */}
                      <div className="flex items-center gap-2">
                        <Car className="h-5 w-5 text-gray-600" />
                        <div>
                          <div className="font-semibold text-gray-900 text-sm">
                            {unit.unidad}
                          </div>
                          {unit.velocidadMax && (
                            <div className="text-xs text-red-600 font-medium">
                              Máx: {unit.velocidadMax} km/h
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="relative">
                        <div className="w-full h-6 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-500 ${
                              hasSpeedViolation
                                ? 'bg-red-500'
                                : isSelected
                                  ? 'bg-blue-700'
                                  : 'bg-gray-900'
                            }`}
                            style={{ width: `${Math.max(barWidth, 2)}%` }}
                          />
                        </div>
                      </div>

                      {/* Distance */}
                      <div className="text-right">
                        <div className={`text-lg font-bold ${hasSpeedViolation ? 'text-red-700' : 'text-gray-900'}`}>
                          {unit.kmTotal.toFixed(2)} km
                        </div>
                        <div className="text-xs text-gray-500">
                          Distancia recorrida
                        </div>
                      </div>

                      {/* Time */}
                      <div className="text-right">
                        <div className="text-lg font-medium text-orange-600">
                          {unit.duracionTotal}
                        </div>
                        <div className="text-xs text-gray-500">
                          Tiempo total
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
