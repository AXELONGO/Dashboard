import { type NextRequest, NextResponse } from "next/server"

// Google Sheets configuration - Public sheet access
const SHEET_ID = "1vjKADJdBxPQBi4eq7FF-BnsAmbIqvovR_JHKTf161CY"

interface VehicleRecord {
  fecha: string
  unidad: string
  kmTotal: number
  duracionTotal: string
}

export async function GET(request: NextRequest) {
  console.log("API route called - using public Google Sheets access")

  try {
    // Use the public CSV export URL for Google Sheets
    // This works for publicly shared sheets without requiring an API key
    const csvUrl = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=0`
    console.log("Fetching from public CSV URL:", csvUrl)

    const response = await fetch(csvUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; VehicleDashboard/1.0)",
      },
    })

    console.log("Response status:", response.status)

    if (!response.ok) {
      console.error("Google Sheets public access error:", response.status)
      
      return NextResponse.json(
        {
          error: `Error accessing public Google Sheets: ${response.status}`,
          troubleshooting: {
            message: "Make sure the Google Sheet is shared publicly",
            steps: [
              "1. Open the Google Sheet",
              "2. Click 'Share' button",
              "3. Change access to 'Anyone with the link can view'",
              "4. Make sure the sheet name matches or is the first sheet",
            ],
          },
        },
        { status: response.status },
      )
    }

    // Get the CSV data
    const csvText = await response.text()
    console.log("CSV data received (first 200 chars):", csvText.substring(0, 200))

    if (!csvText || csvText.trim().length === 0) {
      return NextResponse.json({
        data: [],
        message: "No data found in the sheet",
      })
    }

    // Parse CSV data
    const lines = csvText.trim().split('\n')
    console.log("Number of lines:", lines.length)

    if (lines.length <= 1) {
      return NextResponse.json({
        data: [],
        message: "Only header row found, no data",
      })
    }

    // Parse CSV manually (simple parser for our use case)
    const parseCSVLine = (line: string): string[] => {
      const result: string[] = []
      let current = ''
      let inQuotes = false
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i]
        
        if (char === '"') {
          inQuotes = !inQuotes
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim())
          current = ''
        } else {
          current += char
        }
      }
      
      result.push(current.trim())
      return result
    }

    const header = parseCSVLine(lines[0])
    console.log("Header row:", header)

    // Process the data rows
    const records: VehicleRecord[] = []

    for (let i = 1; i < lines.length; i++) {
      const row = parseCSVLine(lines[i])
      if (!row || row.length === 0) continue

      // Assuming the structure: FECHA, UNIDAD, KM TOTAL, DURACION TOTAL
      const fecha = row[0] || ""
      const unidad = row[1] || ""
      const kmTotalStr = row[2] || ""
      const duracionTotal = row[3] || ""

      // Parse KM Total - convert to number
      let kmTotal = 0
      if (kmTotalStr) {
        // Remove any non-numeric characters except decimal point
        const cleanKm = kmTotalStr.replace(/[^\d.-]/g, '')
        kmTotal = Number.parseFloat(cleanKm) || 0
      }

      const record: VehicleRecord = {
        fecha: fecha,
        unidad: unidad,
        kmTotal: kmTotal,
        duracionTotal: duracionTotal,
      }

      // Only add records with valid data
      if (record.fecha && record.unidad && record.kmTotal > 0) {
        records.push(record)
      }
    }

    console.log("Processed records:", records.length)
    console.log("Sample processed records:", records.slice(0, 3))

    // Group by date
    const groupedData = records.reduce(
      (acc, record) => {
        const fecha = record.fecha

        if (!acc[fecha]) {
          acc[fecha] = {
            fecha,
            unidades: [],
          }
        }

        // Add the unit data
        acc[fecha].unidades.push({
          unidad: record.unidad,
          kmTotal: record.kmTotal,
          duracionTotal: record.duracionTotal,
        })

        return acc
      },
      {} as Record<string, any>,
    )

    const result = Object.values(groupedData)

    // Sort by date (most recent first)
    result.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())

    console.log("Final grouped result:", result)

    return NextResponse.json({
      data: result,
      debug: {
        totalLines: lines.length,
        processedRecords: records.length,
        groupedDays: result.length,
        sampleData: records.slice(0, 3),
        dateRange: result.length > 0 ? `${result[result.length - 1].fecha} to ${result[0].fecha}` : "No dates",
        accessMethod: "Public CSV export",
      },
    })
  } catch (error) {
    console.error("Detailed error:", error)

    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error",
        stack: error instanceof Error ? error.stack : undefined,
        note: "This endpoint uses public Google Sheets access without API key",
      },
      { status: 500 },
    )
  }
}
