"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, Loader2, Info } from 'lucide-react'

export default function TestSheetsConnection() {
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [debugInfo, setDebugInfo] = useState<any>(null)

  const testConnection = async () => {
    setIsLoading(true)
    setError(null)
    setResult(null)
    setDebugInfo(null)

    try {
      console.log("Making request to /api/sheets")

      const response = await fetch("/api/sheets", {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })

      console.log("Response status:", response.status)
      console.log("Response headers:", Object.fromEntries(response.headers.entries()))

      const contentType = response.headers.get("content-type")
      console.log("Content-Type:", contentType)

      if (!contentType || !contentType.includes("application/json")) {
        const textResponse = await response.text()
        console.error("Non-JSON response:", textResponse.substring(0, 500))
        throw new Error(
          `Server returned ${contentType || "unknown content type"} instead of JSON. Response: ${textResponse.substring(0, 200)}...`,
        )
      }

      const data = await response.json()
      console.log("Parsed JSON data:", data)

      if (!response.ok) {
        throw new Error(data.error || `HTTP ${response.status}`)
      }

      setResult(data)
      setDebugInfo(data.debug)
    } catch (err) {
      console.error("Full error:", err)
      setError(err instanceof Error ? err.message : "Error desconocido")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4" style={{ fontFamily: "Poppins, sans-serif" }}>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Test de Conexión Google Sheets</h1>
          <p className="text-gray-600">Prueba la conexión con tu hoja de cálculo pública de Google Sheets</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Probar Conexión</CardTitle>
            <CardDescription>
              Haz clic en el botón para probar si la conexión con Google Sheets funciona correctamente (sin API key)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button onClick={testConnection} disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Probando conexión...
                </>
              ) : (
                "Probar Conexión"
              )}
            </Button>

            {error && (
              <Alert variant="destructive">
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Error:</strong> {error}
                </AlertDescription>
              </Alert>
            )}

            {result && !error && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>¡Conexión exitosa!</strong> Se encontraron {result.data?.length || 0} días de datos.
                </AlertDescription>
              </Alert>
            )}

            {debugInfo && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Debug Info:</strong>
                  <br />• Líneas totales: {debugInfo.totalLines}
                  <br />• Registros procesados: {debugInfo.processedRecords}
                  <br />• Días agrupados: {debugInfo.groupedDays}
                  <br />• Método de acceso: {debugInfo.accessMethod}
                </AlertDescription>
              </Alert>
            )}

            {result && (
              <Card>
                <CardHeader>
                  <CardTitle>Datos Obtenidos</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="bg-gray-100 p-4 rounded-lg overflow-auto text-sm max-h-96">
                    {JSON.stringify(result, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Información de Configuración</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-1 gap-4 text-sm">
              <div>
                <strong>Sheet ID:</strong>
                <br />
                <code className="bg-gray-100 px-2 py-1 rounded text-xs break-all">
                  1vjKADJdBxPQBi4eq7FF-BnsAmbIqvovR_JHKTf161CY
                </code>
              </div>
              <div>
                <strong>Método de acceso:</strong>
                <br />
                <span className="text-green-600">✓ Acceso público (sin API key)</span>
              </div>
              <div>
                <strong>URL de acceso:</strong>
                <br />
                <code className="bg-gray-100 px-2 py-1 rounded text-xs break-all">
                  https://docs.google.com/spreadsheets/d/1vjKADJdBxPQBi4eq7FF-BnsAmbIqvovR_JHKTf161CY/export?format=csv&gid=0
                </code>
              </div>
              <div>
                <strong>Requisitos:</strong>
                <br />
                <span className="text-blue-600">• La hoja debe estar compartida públicamente</span>
                <br />
                <span className="text-blue-600">• Configuración: "Cualquiera con el enlace puede ver"</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button asChild variant="outline">
            <a href="/">Volver al Dashboard</a>
          </Button>
        </div>
      </div>
    </div>
  )
}
